const db = require("../db");

exports.create = (req, res) => {
  const { name, email, pass, city, lat, long } = req.body;

  const slectQuery = "SELECT * FROM `user` WHERE `email` = ?";

  db.query(slectQuery, [email], function (error, result) {
    if (error) {
      return console.log(error);
    }
    if (result.length === 0) {
      const insertQuery =
        "INSERT INTO `user`(`name`, `email`, `password`,`location`,`lat`,`long`) VALUES (?,?,?,?,?,?)";
      db.query(
        insertQuery,
        [name, email, pass, city, lat, long],
        function (error, result) {
          if (error) {
            return console.log(error);
          }
          return res
            .status(200)
            .json({ status: 1, message: "Account Created Sucessfully" });
        }
      );
    } else {
      return res
        .status(200)
        .json({ status: 2, message: "Email Already Exists" });
    }
  });
};

exports.google = (req, res) => {
  const { name, image, email, city, lat, long } = req.body;

  const slectQuery = "SELECT * FROM `user` WHERE `email` = ?";

  db.query(slectQuery, [email], function (error, result) {
    if (error) {
      return console.log(error);
    }
    if (result.length === 0) {
      const insertQuery =
        "INSERT INTO `user`(`name`,`image`, `email`,`location`,`lat`,`long`) VALUES (?,?,?,?,?,?)";
      db.query(
        insertQuery,
        [name, image, email, city, lat, long],
        function (error, result) {
          if (error) {
            return console.log(error);
          }
          return res
            .status(200)
            .json({ status: 1, message: "Login Successfully." });
        }
      );
    } else {
      const insertQuery =
        "UPDATE `user` SET `image`= ?,`location`= ?,`lat`= ?,`long`= ? WHERE `email` = ?";
      db.query(insertQuery, [image, city, lat, long], function (error, result) {
        if (error) {
          return console.log(error);
        }
        return res
          .status(200)
          .json({ status: 1, message: "Login Successfully." });
      });
    }
  });
};
