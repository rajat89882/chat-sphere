const express = require("express");
const app = express();
const cors = require("cors");
const db = require("./db");
const port = 3001;
app.use(cors());
const bodyParser = require("body-parser");
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("Hello, Node.js!");
});

const loginRoutes = require("./routes/login");

app.use("/api", loginRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
