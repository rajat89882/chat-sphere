import React, { use, useEffect, useState } from "react";
import Slider from "../component/ImageSlider";
import { GoogleLogin, googleLogout } from "@react-oauth/google";
import { jwtDecode } from "jwt-decode"; // Corrected import
import SuccessPop from "../component/SuccessPop";
import ErrorPop from "../component/EroorPop";
import axios from "axios";
import { Link } from "react-router-dom";

export default function Login() {
  const [user, setUser] = useState(null);
  const [Create, setCreate] = useState(false);
  const [HideCreate, seHideCreate] = useState(true);
  const [Eroor, setError] = useState("");
  const [Success, setSuccess] = useState("");
  const [ShowSuccess, setShowSuccess] = useState(false);
  const [showEroor, setShowError] = useState(false);
  const [city, setCity] = useState("");
  const [lat, setlat] = useState("");
  const [long, setlong] = useState("");
  const apiUrl = "https://portfolio.hostingoncloud.in/api/";

  useEffect(() => {
    getCityFromGPS();
  }, []);

  const handleSuccess = async (response) => {
    const decoded = jwtDecode(response.credential);
    setUser(decoded);

    let formData = {
      name: decoded.name,
      image: decoded.picture,
      email: decoded.email,
      city: city,
      lat: lat,
      long: long,
    };

    try {
      const response = await axios.post(apiUrl + "google", formData);
      console.log(response.data);
      if (response.data.status === 1) {
        setShowSuccess(true);
        setSuccess(response.data.message);
        setCreate(false);
        seHideCreate(true);
        setTimeout(() => {
          setShowSuccess(false);
          setSuccess("");
        }, 2000);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleFailure = () => {
    alert("Google Sign-In failed");
  };

  const handleLogout = () => {
    googleLogout();
    setUser(null);
  };

  const CreateAccount = () => {
    setCreate(true);
    seHideCreate(false);
  };

  const SignAccount = () => {
    setCreate(false);
    seHideCreate(true);
  };

  const getCityFromGPS = async () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lon = position.coords.longitude;
          setlat(lat);
          setlong(lon);
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`
          );
          const data = await response.json();

          console.log(data);
          const addressParts = [
            data.address.man_made,
            data.address.city,
            data.address.county,
            data.address.state,
            data.address.postcode,
          ];

          const formattedAddress = addressParts
            .filter((part) => part !== "")
            .join(",");

          setCity(formattedAddress);
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    } else {
      console.log("Geolocation is not supported by this browser.");
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (Create) {
      handleCreate(e);
    } else {
      handleLogin(e);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const email = e.target.user_email.value;
    const pass = e.target.user_password.value;
    const cpass = e.target.user_cpassword.value;

    if (pass !== cpass) {
      setShowError(true);
      setError("Confirm Passwords do not match.");
      setTimeout(() => {
        setShowError(false);
        setError("");
      }, 2000);
      return;
    }

    let formData = {
      name: name,
      email: email,
      pass: pass,
      cpass: cpass,
      city: city,
      lat: lat,
      long: long,
    };

    try {
      const response = await axios.post(apiUrl + "create", formData);
      console.log(response.data);
      if (response.data.status === 1) {
        setShowSuccess(true);
        setSuccess(response.data.message);
        e.target.name.value = "";
        e.target.user_email.value = "";
        e.target.user_password.value = "";
        e.target.user_cpassword.value = "";
        setCreate(false);
        seHideCreate(true);
        setTimeout(() => {
          setShowSuccess(false);
          setSuccess("");
        }, 2000);
      }
      if (response.data.status === 2) {
        setShowError(true);
        setError(response.data.message);
        setTimeout(() => {
          setShowError(false);
          setError("");
        }, 2000);
      }
    } catch (error) {
      console.log(error);
    }
  };
  const handleLogin = (e) => {
    e.preventDefault();
    console.log("aa");
  };
  return (
    <div>
      {/* {!user ? (
        <GoogleLogin onSuccess={handleSuccess} onError={handleFailure} />
      ) : (
        <div>
          <h3>Welcome, {user.name}</h3>
          <img src={user.picture} alt="Profile" />
          <p>Email: {user.email}</p>
          <button onClick={handleLogout}>Logout</button>
        </div>
      )} */}

      {showEroor && (
        <ErrorPop
          message={Eroor}
          onClose={() => {
            setShowError(false);
            setError("");
          }}
        />
      )}
      {ShowSuccess && (
        <SuccessPop
          message={Success}
          onClose={() => {
            setShowSuccess(false);
            setSuccess("");
          }}
        />
      )}

      <section className="login d-block">
        <div className="row align-items-center gap-0">
          <div className="col-md-6">
            <Slider />
          </div>
          <div className="col-md-6 left_login">
            <div className="d-flex flex-column  py-5 gap-5 justify-content-center align-items-center">
              <h2 id="craete">Chat Sphere</h2>
              <form onSubmit={handleFormSubmit}>
                <div className="d-flex flex-column gap-4">
                  <h3>Welcome to Chat Sphere</h3>
                  <div className="d-flex flex-column gap-2">
                    {Create && (
                      <div className="d-flex flex-column gap-1">
                        <label htmlFor="name">User name</label>
                        <input
                          type="text"
                          name="name"
                          id="name"
                          required
                          pattern="[A-Za-z\s]+"
                          title="Only alphabetic characters and spaces are allowed"
                        />
                      </div>
                    )}
                    <div className="d-flex flex-column gap-1">
                      {Create && <label htmlFor="user_name">Email</label>}
                      {HideCreate && (
                        <label htmlFor="user_name">User name or email</label>
                      )}
                      <input
                        type="email"
                        name="user_email"
                        id="user_email"
                        required
                      />
                    </div>
                    <div className="d-flex flex-column gap-1">
                      <label htmlFor="user_password">Password</label>
                      <input
                        type="password"
                        name="user_password"
                        id="user_password"
                        required
                        pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
                        title="Password must contain at least one uppercase letter, one lowercase letter, one digit, one special character (@$!%*?&) and be at least 8 characters long"
                      />
                    </div>
                    {Create && (
                      <div className="d-flex flex-column gap-1">
                        <label htmlFor="user_cpassword">Confirm Password</label>
                        <input
                          type="password"
                          name="user_cpassword"
                          id="user_cpassword"
                          required
                        />
                      </div>
                    )}
                    <div className="d-flex justify-content-end align-items-end">
                      <button type="button" className="forget">
                        Forgot Password
                      </button>
                    </div>
                    <div className="d-flex flex-column justify-content-center align-items-center gap-4 pt-2">
                      {Create && (
                        <button type="submit" className="submit_btn">
                          Craete Account
                        </button>
                      )}
                      {HideCreate && (
                        <button type="submit" className="submit_btn">
                          LogIn
                        </button>
                      )}
                      <div className="line_or">Or</div>
                      <GoogleLogin
                        onSuccess={handleSuccess}
                        onError={handleFailure}
                      />
                      {Create && (
                        <div className="d-flex align-items-center gap-0 new_account">
                          <span>You already in Chat Sphere?</span>

                          <button type="button" onClick={SignAccount}>
                            Sign In
                          </button>
                        </div>
                      )}
                      {HideCreate && (
                        <div className="d-flex align-items-center gap-0 new_account">
                          <span>New to Chat Sphere?</span>

                          <button type="button" onClick={CreateAccount}>
                            Create Account
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
